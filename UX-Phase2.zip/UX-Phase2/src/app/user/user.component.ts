import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  
  email : string;
  password : string;

  constructor(private userLogin: Router) { }

  ngOnInit() {
  }
  submit() {
    if(this.email==null) {
      alert("Enter Valid Email Address");
    }else if(this.password==null) {
      alert("Enter password");
    }else {
      this.userLogin.navigate(['/user-logged']);
    }
  }

}
