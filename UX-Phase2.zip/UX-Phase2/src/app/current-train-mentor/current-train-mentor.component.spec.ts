import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentTrainMentorComponent } from './current-train-mentor.component';

describe('CurrentTrainMentorComponent', () => {
  let component: CurrentTrainMentorComponent;
  let fixture: ComponentFixture<CurrentTrainMentorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentTrainMentorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentTrainMentorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
