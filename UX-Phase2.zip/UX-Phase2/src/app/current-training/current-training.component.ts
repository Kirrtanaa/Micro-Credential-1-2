import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  constructor(private httpservice : HttpClient) { }

  course : string[];

  ngOnInit() {
    this.httpservice.get('../../assets/userCurrent.json').subscribe(

      data=>{
        this.course = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }
}
