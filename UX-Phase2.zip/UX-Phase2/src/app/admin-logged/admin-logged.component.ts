import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-logged',
  templateUrl: './admin-logged.component.html',
  styleUrls: ['./admin-logged.component.css']
})
export class AdminLoggedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
