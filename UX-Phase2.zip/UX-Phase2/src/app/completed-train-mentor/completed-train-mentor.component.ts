import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-completed-train-mentor',
  templateUrl: './completed-train-mentor.component.html',
  styleUrls: ['./completed-train-mentor.component.css']
})
export class CompletedTrainMentorComponent implements OnInit {

  constructor(private httpservice : HttpClient) { }

  course : string[];

  ngOnInit() {
    this.httpservice.get('../../assets/mentorCompleted.json').subscribe(

      data=>{
        this.course = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }

}
